/** ProteinMPNN's output channel order; X is the unknown residue. */
export const ALPHABET = 'ACDEFGHIKLMNPQRSTVWYX' as const;
export type ModelFamily = 'proteinmpnn' | 'solublempnn' | 'ca';
export type Vec3 = readonly [number, number, number];
export interface Residue {
  chain: string;
  /** Original PDB residue number (not an array index). */
  number: number;
  insertionCode?: string;
  name?: string;
  aminoAcid?: string;
  atoms: { N?: Vec3; CA?: Vec3; C?: Vec3; O?: Vec3 };
}
export interface CoordinateInput {
  /** Flattened [N,4,3] in N,CA,C,O order, or [N,3] for CA-only input. Å. */
  coordinates: ArrayLike<number>;
  atomMode?: 'backbone' | 'ca';
  sequence?: string;
  chainIds?: readonly string[];
  residueNumbers?: ArrayLike<number>;
  insertionCodes?: readonly string[];
  /** Optional explicit positional encoding indices, one per residue. */
  residueIndices?: ArrayLike<number>;
  /** Explicit 0/1 validity mask. Nonfinite coordinates always invalidate a residue. */
  mask?: ArrayLike<number>;
}
export interface Structure {
  readonly length: number;
  readonly atomMode: 'backbone' | 'ca';
  readonly coordinates: Float32Array;
  readonly sequence: string;
  readonly chainIds: readonly string[];
  readonly residueNumbers: Int32Array;
  readonly insertionCodes: readonly string[];
  readonly residueIndices: Int32Array;
  readonly chainEncoding: Int32Array;
  readonly mask: Float32Array;
}
export type ResidueRef = number | { chain: string; number: number; insertionCode?: string };
export type AABias = Readonly<Record<string, number>>;
export interface PositionBias { position: ResidueRef; bias: AABias }
export interface PositionOmission { position: ResidueRef; aminoAcids: string }
export interface TiedGroup { positions: readonly ResidueRef[]; /** Upstream divides weighted logits by group size, not sum of weights. */ weights?: readonly number[] }
export interface PSSMOptions {
  /** Flattened [N,21], normalized probability distributions. */
  probabilities?: ArrayLike<number>;
  coefficients?: ArrayLike<number>;
  mix?: number;
  useBias?: boolean;
  logOdds?: ArrayLike<number>;
  threshold?: number;
  useLogOdds?: boolean;
}
export interface ExecutionOptions {
  seed?: number;
  signal?: AbortSignal;
  onProgress?: (progress: { completed: number; total: number; phase: 'sample' | 'score' | 'conditional' }) => void;
}
export interface DesignOptions extends ExecutionOptions {
  temperature?: number;
  designChains?: readonly string[];
  fixedPositions?: readonly ResidueRef[];
  /** If supplied, only these positions can be designed. */
  designPositions?: readonly ResidueRef[];
  omitAminoAcids?: string;
  biasAminoAcids?: AABias;
  biasByResidue?: readonly PositionBias[];
  omitByResidue?: readonly PositionOmission[];
  pssm?: PSSMOptions;
  tiedPositions?: readonly (TiedGroup | readonly ResidueRef[])[];
  /** Upstream applies residue-specific constraints from the last group member.
   * 'intersection' instead combines omissions and averages biases; PSSMs must agree. */
  tiedConstraintMode?: 'upstream' | 'intersection';
  /** A complete zero-based permutation. Tied groups are made contiguous. */
  decodingOrder?: ArrayLike<number>;
  /** Supply upstream randn to reproduce its decoding order; RNG streams otherwise differ. */
  orderNoise?: ArrayLike<number>;
}
export interface PrepareOptions {
  backboneNoise?: number;
  seed?: number;
  maxLength?: number;
  signal?: AbortSignal;
  /** Optional precomputed [N,K] neighbors and adjusted CA distances. */
  graph?: NeighborGraph;
}
export interface NeighborGraph { indices: Int32Array; distances: Float32Array; k: number }
export interface ModelManifest {
  format: 'proteinmpnn-onnx';
  version: 1;
  family: ModelFamily;
  modelName: string;
  alphabet: typeof ALPHABET;
  hiddenDim: number;
  decoderLayers: number;
  numEdges: number;
  atomMode: 'backbone' | 'ca';
  files: { encoder: string; decoderStep: string; decoderFull: string; embedding: string };
  sha256: Record<string, string>;
  provenance?: { upstreamCommit?: string; checkpointSha256?: string; exporter?: string };
}
export interface EncodedStructure { nodes: Float32Array; edges: Float32Array; graph: NeighborGraph }
export interface DecoderStepInput {
  batchSize: number;
  k: number;
  center: Float32Array;
  neighborHidden: Float32Array;
  neighborSequence: Float32Array;
  neighborEncoder: Float32Array;
  edges: Float32Array;
  backward: Float32Array;
  mask: Float32Array;
}
export interface DecoderStepOutput { logits: Float32Array; hidden: Float32Array }
/** Implement this interface to provide another inference engine. Arrays use row-major layout. */
export interface InferenceBackend {
  readonly manifest: ModelManifest;
  readonly embedding: Float32Array;
  encode(structure: Structure, graph: NeighborGraph): Promise<EncodedStructure>;
  step(input: DecoderStepInput): Promise<DecoderStepOutput>;
  full(encoded: EncodedStructure, mask: Float32Array, sequence: Int32Array, backward: Float32Array): Promise<Float32Array>;
  dispose(): Promise<void>;
}
export interface ScoreResult {
  sequence: string;
  /** Mean negative log likelihood in nats. null if there are no selected valid residues. */
  score: number | null;
  globalScore: number | null;
  /** Flattened [N,21], untempered model log probabilities. */
  logProbabilities: Float32Array;
  perResidue: Float32Array;
  decodingOrder: Int32Array;
}
export interface SampleResult extends ScoreResult {
  chains: Readonly<Record<string, string>>;
  /** Actual constrained sampling distributions [N,21]; zero rows at fixed positions. */
  probabilities: Float32Array;
  designMask: Float32Array;
  sequenceRecovery: number | null;
  temperature: number;
  seed: number;
}
