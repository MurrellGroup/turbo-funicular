import { ProteinMPNN, type InferenceBackend, type Structure } from 'proteinmpnn-web';
// Implement encode(), step(), full(), dispose(), manifest and embedding in your own runtime.
// See docs/model-format.md for every tensor layout.
export async function designWithRuntime(backend:InferenceBackend,structure:Structure){
 const model=new ProteinMPNN(backend);
 try{return await (await model.prepare(structure)).sample({seed:42});}
 finally{await model.dispose();}
}
