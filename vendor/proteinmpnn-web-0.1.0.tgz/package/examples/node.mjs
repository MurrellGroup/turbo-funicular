// node examples/node.mjs tests/fixtures/example.pdb
import { readFile } from 'node:fs/promises';
import { ProteinMPNN, modelManifestURL } from '../dist/index.js'; // in an installed package: 'proteinmpnn-web'
const pdb=await readFile(process.argv[2]??'tests/fixtures/example.pdb','utf8');
const model=await ProteinMPNN.load(modelManifestURL('proteinmpnn','v_48_020'),{backend:'wasm',numThreads:1});
try {
 const protein=await model.preparePDB(pdb);
 const result=await protein.sample({seed:42,temperature:.1});
 console.log(JSON.stringify({sequence:result.sequence,chains:result.chains,score:result.score,globalScore:result.globalScore,seed:result.seed},null,2));
} finally {await model.dispose();}
