// Compile with your application's bundler, then:
// const worker = new Worker(new URL('./worker.ts', import.meta.url), { type: 'module' });
// worker.postMessage({ type:'design', id:'one', manifestURL:'https://app.test/models/proteinmpnn/v_48_020/manifest.json', pdb, options:{seed:42} });
// worker.postMessage({ type:'cancel', id:'one' });
import { ProteinMPNN, type DesignOptions } from 'proteinmpnn-web';
const jobs=new Map<string,AbortController>();
self.addEventListener('message',async(event:MessageEvent)=>{
 const message=event.data;
 if(message.type==='cancel'){jobs.get(message.id)?.abort();return;}
 if(message.type!=='design')return;
 if(jobs.has(message.id)){self.postMessage({type:'error',id:message.id,error:'Duplicate job id'});return;}
 const controller=new AbortController();jobs.set(message.id,controller);
 let model:ProteinMPNN|undefined;
 try {
  model=await ProteinMPNN.load(message.manifestURL,{backend:'auto',wasmPaths:'/onnxruntime/',signal:controller.signal});
  const protein=await model.preparePDB(message.pdb,{signal:controller.signal});
  const options:DesignOptions={...message.options,signal:controller.signal,onProgress:progress=>self.postMessage({type:'progress',id:message.id,...progress})};
  const result=await protein.sample(options);
  self.postMessage({type:'result',id:message.id,result});
 }catch(error){self.postMessage({type:'error',id:message.id,error:error instanceof Error?error.message:String(error)});}
 finally{await model?.dispose();jobs.delete(message.id);}
});
