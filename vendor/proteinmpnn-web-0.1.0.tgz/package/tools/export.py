#!/usr/bin/env python3
"""Export official ProteinMPNN checkpoints into portable, dynamic-shape ONNX graphs.
No Python or PyTorch is required by the resulting JS library.
"""
import argparse
import hashlib
import json
import pathlib
import sys
import urllib.request
import numpy as np
import torch
from torch import nn
import onnx

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'vendor'))
from protein_mpnn_utils import ProteinMPNN, gather_nodes, cat_neighbors_nodes

ALPHABET = 'ACDEFGHIKLMNPQRSTVWYX'
CATALOG = {'proteinmpnn': ('vanilla_model_weights', ['v_48_002','v_48_010','v_48_020','v_48_030']),
           'solublempnn': ('soluble_model_weights', ['v_48_010','v_48_020']),
           'ca': ('ca_model_weights', ['v_48_002','v_48_010','v_48_020'])}
# Vendored source provenance is recorded separately; downloads can be pinned with --revision.
UPSTREAM_REVISION = '8907e6671bfbfc92303b5f79c4b5e6ce47cdef57'

def sha256(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def load_model(checkpoint, family):
    state = torch.load(checkpoint, map_location='cpu', weights_only=True)
    weights = state['model_state_dict']
    hidden = weights['W_s.weight'].shape[1]
    enc_layers = max(int(k.split('.')[1]) for k in weights if k.startswith('encoder_layers.')) + 1
    dec_layers = max(int(k.split('.')[1]) for k in weights if k.startswith('decoder_layers.')) + 1
    model = ProteinMPNN(21, hidden, hidden, hidden, num_encoder_layers=enc_layers,
                        num_decoder_layers=dec_layers, k_neighbors=int(state['num_edges']),
                        augment_eps=0, dropout=0, ca_only=family == 'ca').eval()
    model.load_state_dict(weights, strict=True)
    return model, state

class Encoder(nn.Module):
    """Same features as upstream, gathering BEFORE distance expansion to use O(NK) memory.
    Neighbor search and its adjusted distances are supplied by the caller.
    """
    def __init__(self, model, ca_only=False):
        super().__init__()
        self.features = model.features
        self.W_e = model.W_e
        self.layers = model.encoder_layers
        self.ca_only = ca_only

    def rbf_pair(self, a, b, neighbors):
        d = torch.sqrt(torch.sum((a.unsqueeze(2) - gather_nodes(b, neighbors))**2, dim=-1) + 1e-6)
        return self.features._rbf(d)

    def ca_orientation(self, ca, neighbors):
        # The upstream cross() calls omit dim; specify the Cartesian axis for ONNX.
        normalize = lambda x: torch.nn.functional.normalize(x, dim=-1)
        dx = ca[:,1:] - ca[:,:-1]
        length = torch.linalg.vector_norm(dx,dim=-1)
        unit = normalize(dx * ((length > 3.6) & (length < 4.0)).unsqueeze(-1))
        u2, u1 = unit[:,:-2], unit[:,1:-1]
        normal = normalize(torch.cross(u2,u1,dim=-1))
        axis = normalize(u2-u1)
        frame = torch.stack([axis,normal,torch.cross(axis,normal,dim=-1)],2).reshape(1,ca.shape[1]-3,9)
        frame = torch.cat([torch.zeros_like(ca[:,:1]).repeat(1,1,3),frame,torch.zeros_like(ca[:,:2]).repeat(1,1,3)],1)
        nf = gather_nodes(frame,neighbors).reshape(1,ca.shape[1],neighbors.shape[2],3,3)
        frame = frame.reshape(1,ca.shape[1],3,3)
        delta = gather_nodes(ca,neighbors)-ca.unsqueeze(2)
        direction = normalize(torch.matmul(frame.unsqueeze(2),delta.unsqueeze(-1)).squeeze(-1))
        rotation = torch.matmul(frame.unsqueeze(2).transpose(-1,-2),nf)
        xx,yy,zz = rotation[...,0,0],rotation[...,1,1],rotation[...,2,2]
        magnitudes = .5*torch.sqrt(torch.abs(1+torch.stack([xx-yy-zz,-xx+yy-zz,-xx-yy+zz],-1)))
        signs = torch.sign(torch.stack([rotation[...,2,1]-rotation[...,1,2],rotation[...,0,2]-rotation[...,2,0],rotation[...,1,0]-rotation[...,0,1]],-1))
        w = torch.sqrt(torch.relu(1+xx+yy+zz)).unsqueeze(-1)/2
        quaternion = normalize(torch.cat([signs*magnitudes,w],-1))
        return torch.cat([direction,quaternion],-1)

    def forward(self, coordinates, mask, residue_idx, chains, neighbors, distances):
        f = self.features
        if self.ca_only:
            ca = coordinates
            prev = torch.cat([torch.zeros_like(ca[:, :1]), ca[:, :-1]], 1)
            nxt = torch.cat([ca[:, 1:], torch.zeros_like(ca[:, :1])], 1)
            pairs = [(prev,prev),(nxt,nxt),(prev,ca),(prev,nxt),(ca,prev),(ca,nxt),(nxt,prev),(nxt,ca)]
            orientation = self.ca_orientation(ca, neighbors)
        else:
            n, ca, c, o = coordinates.unbind(2)
            b, d = ca-n, c-ca
            cb = -0.58273431*torch.cross(b,d,dim=-1) + 0.56802827*b - 0.54067466*d + ca
            pairs = [(n,n),(c,c),(o,o),(cb,cb),(ca,n),(ca,c),(ca,o),(ca,cb),(n,c),(n,o),(n,cb),
                     (cb,c),(cb,o),(o,c),(n,ca),(c,ca),(o,ca),(cb,ca),(c,n),(o,n),(cb,n),(c,cb),(o,cb),(c,o)]
        rbfs = [f._rbf(distances)] + [self.rbf_pair(a,b,neighbors) for a,b in pairs]
        offset = residue_idx.unsqueeze(-1) - gather_nodes(residue_idx.unsqueeze(-1), neighbors).squeeze(-1)
        same_chain = (chains.unsqueeze(-1) == gather_nodes(chains.unsqueeze(-1), neighbors).squeeze(-1)).long()
        positional = f.embeddings(offset, same_chain)
        parts = [positional, *rbfs]
        if self.ca_only:
            parts.append(orientation)
        e = f.norm_edges(f.edge_embedding(torch.cat(parts,-1)))
        nodes = torch.zeros_like(e[:,:,0,:])
        edges = self.W_e(e)
        attend = mask.unsqueeze(-1) * gather_nodes(mask.unsqueeze(-1), neighbors).squeeze(-1)
        for layer in self.layers:
            nodes, edges = layer(nodes,edges,neighbors,mask,attend)
        return nodes.squeeze(0), edges.squeeze(0)

class DecoderStep(nn.Module):
    """A batch of independent residue steps, with neighbor caches gathered by the caller."""
    def __init__(self, model):
        super().__init__()
        self.layers, self.output = model.decoder_layers, model.W_out
    def forward(self, center, neighbor_hidden, neighbor_sequence, neighbor_encoder, edges, backward, mask):
        bw = (mask[:,None]*backward).unsqueeze(-1)
        fw = (mask[:,None]*(1-backward)).unsqueeze(-1)
        future = fw*torch.cat([edges,torch.zeros_like(neighbor_sequence),neighbor_encoder],-1)
        h = center
        states = []
        for i, layer in enumerate(self.layers):
            past = torch.cat([edges,neighbor_sequence,neighbor_hidden[i]],-1)
            h = layer(h[:,None], (bw*past+future)[:,None], mask_V=mask[:,None]).squeeze(1)
            states.append(h)
        return self.output(h), torch.stack(states)

class DecoderFull(nn.Module):
    """Parallel teacher-forced scoring, including the all-forward unconditional case."""
    def __init__(self, model):
        super().__init__()
        self.layers, self.output, self.embedding = model.decoder_layers, model.W_out, model.W_s
    def forward(self, nodes, edges, neighbors, mask, sequence, backward):
        nodes, edges, neighbors, mask = nodes[None],edges[None],neighbors[None],mask[None]
        h_s = self.embedding(sequence[None])
        h_es = cat_neighbors_nodes(h_s,edges,neighbors)
        future = cat_neighbors_nodes(nodes,cat_neighbors_nodes(torch.zeros_like(h_s),edges,neighbors),neighbors)
        bw = (mask[:,:,None]*backward[None]).unsqueeze(-1)
        fw = (mask[:,:,None]*(1-backward[None])).unsqueeze(-1)
        h = nodes
        for layer in self.layers:
            h = layer(h, bw*cat_neighbors_nodes(h,h_es,neighbors)+fw*future,mask)
        return self.output(h).squeeze(0)

def export_graph(module, args, path, names, outputs, dynamic):
    with torch.no_grad():
        torch.onnx.export(module.eval(), args, str(path), input_names=names, output_names=outputs,
                          dynamic_axes=dynamic, opset_version=17, dynamo=False,
                          do_constant_folding=True, external_data=False)
    graph = onnx.load(str(path))
    onnx.checker.check_model(graph)

def export_model(checkpoint, family, name, out, revision=UPSTREAM_REVISION):
    torch.set_num_threads(1)
    model, state = load_model(checkpoint, family)
    out = pathlib.Path(out); out.mkdir(parents=True,exist_ok=True)
    n, k, h, d = 8, min(8,int(state['num_edges'])), model.hidden_dim, len(model.decoder_layers)
    torch.manual_seed(193)
    x = torch.randn(1,n,3) if family == 'ca' else torch.randn(1,n,4,3)
    mask = torch.ones(1,n)
    idx = torch.arange(n)[None]
    chains = torch.ones(1,n,dtype=torch.long)
    neighbor = torch.arange(k)[None,None].expand(1,n,k).contiguous()
    distance = torch.rand(1,n,k)*10
    encoder = Encoder(model,family=='ca')
    export_graph(encoder,(x,mask,idx,chains,neighbor,distance),out/'encoder.onnx',
        ['coordinates','mask','residue_idx','chains','neighbors','distances'],['nodes','edges'],
        {**{key:{1:'N'} for key in ['coordinates','mask','residue_idx','chains']},
         **{key:{1:'N',2:'K'} for key in ['neighbors','distances']},'nodes':{0:'N'},'edges':{0:'N',1:'K'}})
    step = DecoderStep(model)
    step_args = (torch.randn(1,h),torch.randn(d,1,k,h),torch.randn(1,k,h),torch.randn(1,k,h),torch.randn(1,k,h),torch.zeros(1,k),torch.ones(1))
    export_graph(step,step_args,out/'decoder-step.onnx',
        ['center','neighbor_hidden','neighbor_sequence','neighbor_encoder','edges','backward','mask'],['logits','hidden'],
        {'center':{0:'B'},'neighbor_hidden':{1:'B',2:'K'},
         **{key:{0:'B',1:'K'} for key in ['neighbor_sequence','neighbor_encoder','edges','backward']},
         'mask':{0:'B'},'logits':{0:'B'},'hidden':{1:'B'}})
    with torch.no_grad():
        nodes, edges = encoder(x,mask,idx,chains,neighbor,distance)
    export_graph(DecoderFull(model),(nodes,edges,neighbor[0],mask[0],idx[0]%21,torch.zeros(n,k)),out/'decoder-full.onnx',
        ['nodes','edges','neighbors','mask','sequence','backward'],['logits'],
        {**{key:{0:'N'} for key in ['nodes','mask','sequence','logits']},
         **{key:{0:'N',1:'K'} for key in ['edges','neighbors','backward']}})
    model.W_s.weight.detach().numpy().astype('<f4').tofile(out/'embedding.bin')
    files = {'encoder':'encoder.onnx','decoderStep':'decoder-step.onnx','decoderFull':'decoder-full.onnx','embedding':'embedding.bin'}
    manifest = dict(format='proteinmpnn-onnx',version=1,family=family,modelName=name,alphabet=ALPHABET,
        hiddenDim=h,decoderLayers=d,numEdges=int(state['num_edges']),atomMode='ca' if family=='ca' else 'backbone',
        files=files,sha256={file:sha256(out/file) for file in files.values()},
        provenance={'upstreamCommit':revision,'checkpointSha256':sha256(checkpoint),'exporter':'proteinmpnn-web/0.1.0'})
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return model, manifest

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',type=pathlib.Path)
    p.add_argument('--family',choices=CATALOG,default='proteinmpnn')
    p.add_argument('--model',default='v_48_020')
    p.add_argument('--output',type=pathlib.Path,default=ROOT/'models')
    p.add_argument('--all',action='store_true',help='Download and export all nine official checkpoints')
    p.add_argument('--revision',default=UPSTREAM_REVISION)
    args = p.parse_args()
    jobs = [(family,name) for family,(_,names) in CATALOG.items() for name in names] if args.all else [(args.family,args.model)]
    if args.all and args.checkpoint: p.error('--all and --checkpoint are mutually exclusive')
    for family,name in jobs:
        checkpoint = args.checkpoint
        if checkpoint is None:
            directory,names = CATALOG[family]
            if name not in names: p.error(f'{family} has no official checkpoint {name}')
            checkpoint = ROOT/'vendor'/directory/(name+'.pt')
            if not checkpoint.exists():
                checkpoint.parent.mkdir(parents=True,exist_ok=True)
                url = f'https://raw.githubusercontent.com/dauparas/ProteinMPNN/{args.revision}/{directory}/{name}.pt'
                print(f'Downloading {family}/{name}',flush=True)
                with urllib.request.urlopen(url,timeout=120) as response:
                    checkpoint.write_bytes(response.read())
        out = args.output/family/name
        export_model(checkpoint,family,name,out,args.revision)
        print(f'Exported {out}',flush=True)
if __name__ == '__main__': main()
