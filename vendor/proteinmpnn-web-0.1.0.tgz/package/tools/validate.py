#!/usr/bin/env python3
"""Compare exported graphs against upstream; write fixtures consumed by the WASM/browser tests."""
import argparse
import json
import pathlib
import sys
import numpy as np
import torch
import onnxruntime as ort
from export import ROOT, load_model, UPSTREAM_REVISION, sha256
from protein_mpnn_utils import gather_nodes

def inputs(n, ca=False):
    rng=np.random.default_rng(551+n)
    # Asymmetric, realistic-scale synthetic backbone with two chains, a masked residue and a gap.
    xyz=np.zeros((n,4,3),np.float32)
    t=np.arange(n,dtype=np.float32)
    ca_xyz=np.stack([2.3*np.cos(t*1.1),2.3*np.sin(t*1.1),1.55*t],-1)
    for a,offset in enumerate([[-1.1,.2,-.4],[0,0,0],[1.1,.3,.4],[1.8,.7,.6]]):
        xyz[:,a,:]=ca_xyz+offset+rng.normal(0,.09,(n,3))
    mask=np.ones(n,np.float32)
    if n>5: mask[3]=0;xyz[3]=0
    chains=np.ones(n,np.int64);chains[n//2:]=2
    idx=np.arange(n,dtype=np.int64);idx[n//2:]+=100;idx[-2:]+=2
    seq=rng.integers(0,20,n,dtype=np.int64)
    order=rng.permutation(n).astype(np.int64)
    return xyz[:,1] if ca else xyz,mask,idx,chains,seq,order

def as_numpy(value): return value.detach().cpu().numpy()
def check(label,a,b,tol=5e-5):
    error=float(np.max(np.abs(a-b)))
    if not np.allclose(a,b,atol=tol,rtol=tol): raise AssertionError(f'{label}: max error {error}')
    return error

def validate(family,name):
    directory={'proteinmpnn':'vanilla_model_weights','solublempnn':'soluble_model_weights','ca':'ca_model_weights'}[family]
    checkpoint=ROOT/'vendor'/directory/(name+'.pt')
    if not checkpoint.exists():
        import urllib.request
        checkpoint.parent.mkdir(parents=True,exist_ok=True)
        url=f'https://raw.githubusercontent.com/dauparas/ProteinMPNN/{UPSTREAM_REVISION}/{directory}/{name}.pt'
        with urllib.request.urlopen(url,timeout=120) as response:
            checkpoint.write_bytes(response.read())
    model,_=load_model(checkpoint,family)
    torch.set_num_threads(1)
    model_dir=ROOT/'models'/family/name
    manifest=json.loads((model_dir/'manifest.json').read_text())
    if manifest['provenance']['checkpointSha256'] != sha256(checkpoint): raise ValueError('Checkpoint differs from exported model provenance')
    opts=ort.SessionOptions();opts.intra_op_num_threads=1
    sessions={key:ort.InferenceSession(str(model_dir/file),sess_options=opts,providers=['CPUExecutionProvider']) for key,file in [('encode','encoder.onnx'),('step','decoder-step.onnx'),('full','decoder-full.onnx')]}
    errors={}
    for n in ([3,7,17,55] if family=='ca' else [1,7,17,55]):
        x,mask,idx,chains,seq,order=inputs(n,family=='ca')
        tx,tm,ti,tc,ts,to=[torch.from_numpy(v)[None] for v in [x,mask,idx,chains,seq,order]]
        with torch.no_grad():
            ca=tx if family=='ca' else tx[:,:,1]
            raw=model.features._dist(ca,tm)
            distances,neighbors=raw[:2]
            e,ei=model.features(tx,tm,ti,tc)
            nodes=torch.zeros_like(e[:,:,0]);edges=model.W_e(e)
            attend=tm[:,:,None]*gather_nodes(tm[:,:,None],ei).squeeze(-1)
            for layer in model.encoder_layers: nodes,edges=layer(nodes,edges,ei,tm,attend)
            output=sessions['encode'].run(None,{'coordinates':x[None],'mask':mask[None],'residue_idx':idx[None], 'chains':chains[None], 'neighbors':as_numpy(neighbors),'distances':as_numpy(distances)})
            errors[f'{n}/encoder-nodes']=check('encoder nodes',output[0],as_numpy(nodes[0]))
            errors[f'{n}/encoder-edges']=check('encoder edges',output[1],as_numpy(edges[0]))
            rank=np.argsort(order);nei=as_numpy(neighbors[0]);backward=(rank[nei]<rank[:,None]).astype(np.float32)
            feeds={'nodes':output[0],'edges':output[1],'neighbors':nei,'mask':mask,'sequence':seq,'backward':backward}
            logits=sessions['full'].run(None,feeds)[0]
            reference=model(tx,ts,tm,torch.ones_like(tm),ti,tc,torch.ones_like(tm),True,to)[0]
            log_probs=torch.log_softmax(torch.from_numpy(logits),-1).numpy()
            errors[f'{n}/full']=check('full log probabilities',log_probs,as_numpy(reference))
            unconditional=model.unconditional_probs(tx,tm,ti,tc)[0]
            unconditional_logits=sessions['full'].run(None,{**feeds,'backward':np.zeros_like(backward)})[0]
            errors[f'{n}/unconditional']=check('unconditional',torch.log_softmax(torch.from_numpy(unconditional_logits),-1).numpy(),as_numpy(unconditional))
            h=model.hidden_dim;d=len(model.decoder_layers);k=nei.shape[-1]
            cache=np.zeros((d+1,n,h),np.float32);cache[0]=output[0]
            embedding=np.zeros((n,h),np.float32);step_logits=np.zeros((n,21),np.float32)
            for t in order:
                args={'center':output[0][t:t+1], 'neighbor_hidden':cache[:d,nei[t]][:,None],
                      'neighbor_sequence':embedding[nei[t]][None], 'neighbor_encoder':output[0][nei[t]][None],
                      'edges':output[1][t:t+1], 'backward':backward[t:t+1], 'mask':mask[t:t+1]}
                step_logit,hidden=sessions['step'].run(None,args)
                step_logits[t]=step_logit[0];cache[1:,t]=hidden[:,0]
                embedding[t]=as_numpy(model.W_s.weight[seq[t]])
            errors[f'{n}/incremental']=check('incremental',torch.log_softmax(torch.from_numpy(step_logits),-1).numpy(),as_numpy(reference))
            # Verify independent batch dimension as used by custom runtimes.
            batch=3
            bargs={key:np.repeat(value,batch,axis=1 if key=='neighbor_hidden' else 0) for key,value in args.items()}
            blogits,_=sessions['step'].run(None,bargs)
            errors[f'{n}/batch']=check('batch',blogits,np.repeat(step_logit,batch,axis=0))
            if n==17:
                noise=np.linspace(.1,1.9,n,dtype=np.float32)
                conditional=model.conditional_probs(tx,ts,tm,torch.ones_like(tm),ti,tc,torch.from_numpy(noise)[None])[0]
                bias=np.zeros(21,np.float32);bias[0]=.4;bias[3]=-.8
                per_bias=np.zeros((1,n,21),np.float32);per_bias[0,4,6]=1.1
                omission=np.zeros((1,n,21),np.float32);omission[0,5,2]=1
                design=tm.clone();design[:,0]=0
                pssm=np.full((1,n,21),1/21,np.float32);coef=np.full((1,n),.4,np.float32)
                lod=np.tile(np.arange(21)>4,(1,n,1)).astype(np.float32)
                sample_kwargs=dict(mask=tm,temperature=.7,omit_AAs_np=np.array([0]*20+[1],np.float32),bias_AAs_np=bias,
                    chain_M_pos=torch.ones_like(tm),omit_AA_mask=torch.from_numpy(omission),pssm_coef=torch.from_numpy(coef),
                    pssm_bias=torch.from_numpy(pssm),pssm_multi=.3,pssm_log_odds_flag=True,pssm_log_odds_mask=torch.from_numpy(lod),
                    pssm_bias_flag=True,bias_by_res=torch.from_numpy(per_bias))
                # Fix categorical draws so reference probabilities are independent of torch's PRNG.
                original=torch.multinomial
                torch.multinomial=lambda probs,num_samples: torch.argmax(probs,-1,keepdim=True)
                try:
                    sampled=model.sample(tx,torch.from_numpy(noise)[None],ts,design,tc,ti,**sample_kwargs)
                    tied=model.tied_sample(tx,torch.from_numpy(noise)[None],ts,design,tc,ti,tied_pos=[[2,8],[6,12]],tied_beta=torch.ones(n),**sample_kwargs)
                finally: torch.multinomial=original
                fixture={'family':family,'modelName':name,'length':n,'coordinates':x.reshape(-1).tolist(),'mask':mask.tolist(),'residueIndices':idx.tolist(),'chains':chains.tolist(),
                    'sequence':''.join('ACDEFGHIKLMNPQRSTVWYX'[i] for i in seq),'order':order.tolist(),'neighbors':nei.reshape(-1).tolist(),'distances':as_numpy(distances).reshape(-1).tolist(),'k':k,
                    'nodes':output[0].reshape(-1).tolist(),'edges':output[1].reshape(-1).tolist(),'logProbabilities':as_numpy(reference).reshape(-1).tolist(),
                    'unconditional':as_numpy(unconditional).reshape(-1).tolist(),'conditional':as_numpy(conditional).reshape(-1).tolist(),'orderNoise':noise.tolist(),
                    'argmaxSample':as_numpy(sampled['S'][0]).tolist(),'samplingProbabilities':as_numpy(sampled['probs'][0]).reshape(-1).tolist(),
                    'argmaxTied':as_numpy(tied['S'][0]).tolist(),'tiedProbabilities':as_numpy(tied['probs'][0]).reshape(-1).tolist()}
                fixture_name=family if name=='v_48_020' else family+'-'+name
                path=ROOT/'tests/fixtures/generated'/f'{fixture_name}.json';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(fixture))
    return errors
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--family',choices=['proteinmpnn','solublempnn','ca','all'],default='all');p.add_argument('--model',default='v_48_020');p.add_argument('--all',action='store_true');args=p.parse_args()
    if args.all:
        from export import CATALOG
        results={family+'/'+name:validate(family,name) for family,(_,names) in CATALOG.items() for name in names}
        (ROOT/'tests/fixtures/generated/all-checkpoints-validation.json').write_text(json.dumps(results,indent=2)+'\n')
        print(json.dumps({key:{'checks':len(errors),'max_abs_error':max(errors.values())} for key,errors in results.items()},indent=2))
        sys.exit(0)
    results={family:validate(family,args.model) for family in (['proteinmpnn','solublempnn','ca'] if args.family=='all' else [args.family])}
    (ROOT/'tests/fixtures/generated/python-validation.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({family:{'checks':len(errors),'max_abs_error':max(errors.values())} for family,errors in results.items()},indent=2))
