# Validation report — 2026-09-08

## Verified in this environment

- TypeScript strict compilation completed successfully.
- **10 input, constraint and lifecycle tests passed.** Coverage includes PDB models, insertion codes, gaps, alternate locations, MSE, missing coordinates, typed-array ownership, reference validation, JSONL/legacy adapters, PSSM formulas, tied policies, fixed residues, seed reproducibility, independent concurrent sampling states and cancellation.
- **3 end-to-end WASM suites passed**, one each for ProteinMPNN, solubleMPNN and CA-only `v_48_020`. These load actual ONNX Runtime Web WASM sessions with actual checkpoint weights. Checks compare encoder outputs, teacher-forced scoring, unconditional probabilities, sequence-conditioned probabilities, backbone-only probabilities, JavaScript graph construction, incremental constrained sampling and tied sampling against upstream PyTorch. PSSM probability mixing, log-odds filtering, global/per-residue biases and residue omissions are exercised together. To compare sampling probabilities independently of different random number generators, the parity test makes both samplers choose argmax; separate tests check seeded stochastic reproducibility.
- **216 Python ONNX/PyTorch numerical checks passed across all nine official checkpoints**: 24 per checkpoint, with four residue lengths per model. Backbone lengths: 1, 7, 17, 55. CA lengths: 3, 7, 17, 55. Each length checks encoder nodes, encoder edges, parallel log probabilities, unconditional probabilities, incremental log probabilities and an independent three-item decoder-step batch. Structures include chain boundaries, positional gaps and masked residues.
- A complete WASM design ran from the upstream `5L33.pdb` example: 106 residues, seed 42, temperature 0.1; mean model negative log likelihood approximately 0.936625 nats. This is a functional integration example, not a biological-quality evaluation.
- All exported ONNX files passed `onnx.checker.check_model`; manifests contain hashes of all four binary assets and their source checkpoint.

Detailed numerical results are in `tests/fixtures/generated/python-validation.json` and `all-checkpoints-validation.json`. The Python gate uses `numpy.allclose(atol=5e-5, rtol=5e-5)`; maximum absolute errors can exceed 5e-5 for larger-magnitude values. For the three default checkpoints, the largest observed absolute error across these graph checks was about 7.28e-5. The WASM default-checkpoint tests use absolute tolerances of 1e-4, or 2e-4 when comparing independently generated neighbor graphs.

## WebGPU validation remains outstanding

The WebGPU backend, provider selection, runtime asset configuration and browser parity harness are implemented. **No successful browser WebGPU execution was obtained in this environment.** Local Chromium provisioning failed, and the available cloud browser rejected the local test URL with `net::ERR_BLOCKED_BY_CLIENT`. No hardware acceleration, browser parity or speedup is claimed on the basis of these tests.

Run the included suite on a machine with Chromium and WebGPU support:

```sh
npm ci
npm run build
npx playwright install chromium --only-shell
npm run test:browser
```

The standalone harness tries Chromium's SwiftShader software WebGPU and checks all three default model families, both WASM and WebGPU, with an absolute log-probability tolerance of 3e-4. Set `CHROMIUM_EXECUTABLE` to a compatible existing Chromium executable if necessary. A successful software-WebGPU run validates API/kernel behavior, not hardware performance. `tests/browser/serve.mjs` also serves an automatic test-only harness on port 8765 for an existing browser. The release ships no application UI.

## Reproduce the numerical gates

```sh
npm test
npm run test:parity
python -m pip install -r tools/requirements.txt
python tools/validate.py --all
```

Missing reference `.pt` files are downloaded from the pinned upstream revision by the Python validation tool. The ready-to-use ONNX weights and default test reference fixtures are already included in the full release; runtime inference and `npm run test:parity` do not need Python or PyTorch.

Test environment: Node.js 24.19.0, TypeScript 5.9.3, ONNX Runtime Web 1.24.3, Python 3.12, PyTorch 2.14.0+cpu, ONNX 1.22.0, Python ONNX Runtime 1.29.0. Tests used one CPU thread. Package versions are recorded for reproducibility; these measurements are not comparative performance benchmarks.

## Remaining limits

No end-to-end hardware WebGPU benchmark, long-protein memory benchmark, biological experimental validation or npm publication was performed. CPU neighbor search is quadratic, and incremental WebGPU inference transfers neighbor caches through CPU memory. The CA cross-product axis correction and other deliberate compatibility differences are documented in `compatibility.md`.
