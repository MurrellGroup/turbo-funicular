# Model hosting

The Git repository and npm package do not contain model weights. The official
converted bundles are stored in the public
[`MurrellLab/webports`](https://huggingface.co/MurrellLab/webports/tree/main/webProteinMPNN)
Hugging Face model repository.

Use `modelManifestURL(family, modelName)` for a supported checkpoint. The
library pins this helper to an immutable Hugging Face commit so a mutable Hub
update cannot silently change inference assets. Every manifest contains the
source checkpoint hash and SHA-256 hashes for all four exported files; those
hashes are verified by default during `ProteinMPNN.load()`.

Applications may instead pass any absolute manifest URL to
`ProteinMPNN.load()`. Keep `encoder.onnx`, `decoder-step.onnx`,
`decoder-full.onnx`, and `embedding.bin` beside that manifest and configure
CORS when the model host and application use different origins. The manifest
format is documented in [model-format.md](model-format.md).

The collection-wide metadata index is
[`webProteinMPNN/catalog.json`](https://huggingface.co/MurrellLab/webports/blob/main/webProteinMPNN/catalog.json).
