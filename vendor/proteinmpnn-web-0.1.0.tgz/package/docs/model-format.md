# Portable model interface, version 1

All floating-point tensors are float32, contiguous, row-major. ONNX indexing tensors are int64; the public JavaScript API accepts Int32Array and handles conversion at the runtime boundary. `N` is residue count, `K = min(N, numEdges)`, `H` is hidden dimension, `D` is decoder depth, and `B` is the number of independent residue steps. Official checkpoints use H=128, D=3, numEdges=48.

Each manifest names three self-contained ONNX graphs plus an embedding table. Graph files embed their own weights; no ONNX external-data sidecars are required. The manifest records family, atom mode, alphabet, dimensions, relative filenames, SHA-256 hashes and upstream/checkpoint provenance. `embedding.bin` is little-endian float32 `[21,H]` for sequence-token embeddings.

## Structure encoder: `encoder.onnx`

| Name | Type | Shape | Meaning |
| --- | --- | --- | --- |
| `coordinates` | float32 | `[1,N,4,3]` or `[1,N,3]` | Backbone N/CA/C/O or CA-only coordinates |
| `mask` | float32 | `[1,N]` | 1 for complete observed residues |
| `residue_idx` | int64 | `[1,N]` | Positional-encoding index; differences matter within a chain |
| `chains` | int64 | `[1,N]` | Chain identities; only equality matters |
| `neighbors` | int64 | `[1,N,K]` | Ordered nearest-neighbor indices, including self |
| `distances` | float32 | `[1,N,K]` | Upstream adjusted CA distances for those neighbors |
| **output `nodes`** | float32 | `[N,H]` | Encoded node states |
| **output `edges`** | float32 | `[N,K,H]` | Encoded edge states |

The caller performs exact nearest-neighbor search with `D_ij = mask_i mask_j sqrt(||CA_i-CA_j||² + 1e-6)` and `D_adjusted = D_ij + (1-mask_i mask_j) max_j(D_ij)`. Sort ascending and select K. Distances for masked rows are zero; masked neighbors of valid rows receive that row's maximum valid distance. Do not substitute raw distances for these inputs. A supplied graph is dimension/range checked but its geometric correctness is the caller's responsibility.

The encoder reproduces the original geometric features, positional encodings and message-passing layers. Gathering atom coordinates before pairwise feature expansion reduces memory to O(NK). Neighbor choice stays outside ONNX, avoiding export-time constants for short structures and permitting application-provided spatial indexing.

## Incremental decoder: `decoder-step.onnx`

| Name | Type | Shape | Meaning |
| --- | --- | --- | --- |
| `center` | float32 | `[B,H]` | Encoder state for each center residue |
| `neighbor_hidden` | float32 | `[D,B,K,H]` | Gathered decoder caches at each layer; layer 0 contains encoder states |
| `neighbor_sequence` | float32 | `[B,K,H]` | Embeddings of revealed amino acids; zero for unrevealed tokens |
| `neighbor_encoder` | float32 | `[B,K,H]` | Gathered original encoder states |
| `edges` | float32 | `[B,K,H]` | Encoded center-to-neighbor edges |
| `backward` | float32 | `[B,K]` | 1 iff neighbor has a lower rank in the decoding permutation |
| `mask` | float32 | `[B]` | Center validity |
| **output `logits`** | float32 | `[B,21]` | Untempered output logits |
| **output `hidden`** | float32 | `[D,B,H]` | New states for cache layers 1 through D |

Initialize cache `[D+1,N,H]` to zero and copy encoder nodes into layer 0. For each center, gather neighbor states for layers 0…D-1. The graph internally advances the center through all decoder layers and returns its new states. Write these into layers 1…D. Only after sampling/revealing an amino acid copy its embedding into the sequence cache.

A tied group is processed in its supplied member order. Update member hidden states immediately but defer **all sequence embeddings in the group** until its shared token has been selected. That distinction is required to match upstream tied sampling. Never batch mutually dependent steps as if they were independent.

Each decoder layer combines the backward edge/sequence/decoder-neighbor feature with the forward edge/zero-sequence/encoder-neighbor feature. The backward and forward masks are multiplied by center validity. They are not additionally multiplied by neighbor validity; the upstream encoder has its own neighbor-validity mask.

## Parallel decoder: `decoder-full.onnx`

| Name | Type | Shape |
| --- | --- | --- |
| `nodes` | float32 | `[N,H]` |
| `edges` | float32 | `[N,K,H]` |
| `neighbors` | int64 | `[N,K]` |
| `mask` | float32 | `[N]` |
| `sequence` | int64 | `[N]` |
| `backward` | float32 | `[N,K]` |
| **output `logits`** | float32 | `[N,21]` |

For teacher forcing, fill `backward[i,j] = rank[neighbors[i,j]] < rank[i]`. For unconditional prediction use all zeros. Apply log-softmax along the 21-channel alphabet dimension in the host. For conditional probabilities use an ordering with the target last and return its row. The convenience API follows upstream's order-noise scaling when constructing that ordering.

## Custom runtimes

Implement `InferenceBackend` and call `new ProteinMPNN(backend)`. The core sampler only needs the manifest, sequence embedding table, `encode`, `step`, `full` and `dispose`. Implementations must return owned output arrays or arrays whose lifetime survives the next backend call. The provided ONNX backend copies outputs before disposing tensors and serializes runtime calls to support multiple independent sampling states safely.
