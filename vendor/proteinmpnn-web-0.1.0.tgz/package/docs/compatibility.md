# Upstream option mapping and compatibility

Reference: [official ProteinMPNN runner](https://github.com/dauparas/ProteinMPNN/blob/8907e6671bfbfc92303b5f79c4b5e6ce47cdef57/protein_mpnn_run.py).

| Upstream flag/input | Library equivalent |
| --- | --- |
| `model_name`, `path_to_model_weights` | Model manifest URL or in-memory `ModelAssets`; custom exporter |
| `use_soluble_model` | Load a `solublempnn` bundle |
| `ca_only` | Load a `ca` bundle, parse CA coordinates |
| `pdb_path` | `parsePDB(text)` / `preparePDB(text)` |
| `pdb_path_chains` | `sample({designChains})`; parser `chains` selects which context chains to include |
| `jsonl_path` | `parseJSONL` + `fromProteinMPNNJSON` from `proteinmpnn-web/legacy` |
| `chain_id_jsonl` | `designChains` / `fromLegacyOptions({chainIds})` |
| `fixed_positions_jsonl` | `fixedPositions` |
| `omit_AAs` | `omitAminoAcids`, default `X` |
| `bias_AA_jsonl` | `biasAminoAcids` |
| `bias_by_res_jsonl` | `biasByResidue` |
| `omit_AA_jsonl` | `omitByResidue` |
| `tied_positions_jsonl` | `tiedPositions`, including weights |
| `pssm_jsonl` | `pssm.probabilities`, `coefficients`, `logOdds` |
| `pssm_multi` | `pssm.mix` |
| `pssm_threshold` | `pssm.threshold`, including ±Infinity |
| `pssm_log_odds_flag` | `pssm.useLogOdds` |
| `pssm_bias_flag` | `pssm.useBias` |
| `sampling_temp` | `temperature` / `sampleMany({temperatures})` |
| `num_seq_per_target` | `sampleMany({numSequences})`, per temperature |
| `batch_size` | `batchSize` bounds concurrent sampling states; different scheduling, same sequence semantics |
| `seed` | `seed`; 0 is deterministic, omitted generates a random seed |
| `backbone_noise` | `prepare({backboneNoise,seed})` |
| `max_length` | `prepare({maxLength})`; default 10,000 |
| `score_only` | `score(sequence?, options?)` |
| `path_to_fasta` | Host reads file; `parseFASTA` + `score(record.sequence)` |
| `conditional_probs_only` | `conditionalProbabilities` |
| `conditional_probs_only_backbone` | `conditionalProbabilities(...,{backboneOnly:true})` |
| `unconditional_probs_only` | `unconditionalProbabilities` |
| `save_score`, `save_probs` | Scores and typed probability arrays returned to caller |
| `out_folder`, `suppress_print` | Application owns output storage and logging; no automatic files or console messages |

## Intentional differences

- This is inference software, not a port of the CLI's file-writing and batching machinery. It does not train models or load Python pickle checkpoints at runtime.
- Fixed and designed chains remain in caller order. No chain shuffling or automatic conversion of identical-sequence context chains into designed chains is performed. List all intended design chains explicitly. Numeric output rows always correspond to input residue rows.
- Flat numeric references are zero-based. Legacy helper dictionaries are one-based within chain. `fromLegacyOptions` accepts one target's already-selected dictionaries, not filenames or an entire multi-target dictionary; applications use the target name to select that value first.
- PDB blank chain IDs become `_`. The parser reads the first MODEL by default; integer numbering gaps become masked X rows unless `fillGaps:false`. Original residue numbers and insertion codes remain addressable. Alternate conformations use the highest total backbone occupancy or an explicit selection rather than mixing atom conformers.
- Default positional indices count rows separately in each chain. This produces the same within-chain differences as upstream's flattened index plus chain offset. Interchain offsets are masked by the chain-equality feature. Supply explicit `residueIndices` for a different mapping or omitted gaps.
- Deterministic seeds are local to this library and do not reproduce NumPy/PyTorch's random streams. Supply explicit decoding order or order noise to compare model probabilities. Neighbor distance ties use index order; `torch.topk` does not specify tie order.
- Backbone augmentation is sampled once per `prepare` and reused for every design or score on that object. Prepare again for a new perturbation. Upstream may draw another perturbation on each model call, including its scoring pass.
- A fixed member pins a tied group. Conflicting fixed identities, overlapping groups and masked members of tied groups are rejected. This prevents upstream's last-member rule from silently overwriting incompatible fixed residues. For fully designed, observed groups, default tied sampling matches upstream's weighted logits and last-member constraints.
- Default per-residue tied constraints are from the last member, matching upstream. The optional `intersection` policy is an extension. Individual fixed rows return zero sampling distributions; upstream `tied_sample` may populate fixed rows.
- PSSM probability rows must be normalized, nonnegative, finite 21-channel distributions. PSSM coefficients and mixing strength must lie in [0,1]. This catches malformed helper data before sampling. The soft log-odds mask and global-omission reintroduction behavior are intentionally preserved.
- The CA orientation exporter specifies the Cartesian cross-product axis explicitly. Upstream omits it, which ambiguously selects the residue axis for exactly six-residue CA inputs in current PyTorch. This release fixes that shape-specific issue rather than reproducing it. At least three CA residues are required. Full-backbone models accept one or more residues.
- The backbone-only conditional API uses one unconditional pass; it yields the same target distribution when the target is decoded first. Sequence-conditioned calculations preserve upstream's relative decoding order of the conditioning residues.
- Errors for empty feasible distributions and conflicting constraints replace undefined or misleading outputs. Empty scoring selections produce `null`; undefined per-residue scores and unrequested conditional rows are `NaN`.

## Scope of acceleration

Geometry and learned message passing execute in ONNX. Neighbor search, residue addressing, constraint handling, seeded sampling and cache gathering execute in JavaScript. WASM is actual ONNX Runtime Web execution, not a Python service. WebGPU uses ORT's GPU execution provider with CPU placement for unsupported graph operations. The current incremental cache is held in CPU memory; GPU graph capture and a fully GPU-resident sampling loop are future optimizations, not implemented features.
